google_username = "YOUR_GOOGLE_LOGIN"
google_password = "YOUR_GOOGLE_PASSWORD"

maxattempts = 4
